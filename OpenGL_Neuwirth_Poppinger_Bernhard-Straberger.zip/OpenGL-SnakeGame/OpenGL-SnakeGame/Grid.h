#pragma once
class Grid
{
public: 
	static const int GRID_SIZE = 30; // Number of fields along one axis
	static const float GRID_STEP; // Size of each field (normalized coordinates)
	static const float BORDER_OFFSET; // Border boundarys
};

