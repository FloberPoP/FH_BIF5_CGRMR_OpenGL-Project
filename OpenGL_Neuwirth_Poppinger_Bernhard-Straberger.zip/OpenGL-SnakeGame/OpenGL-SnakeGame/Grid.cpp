#include "Grid.h"

const float Grid::GRID_STEP = (1.8f / Grid::GRID_SIZE);
const float Grid::BORDER_OFFSET = 0.9f;

// Grid rendering